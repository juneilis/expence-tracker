
import java.util.Optional;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;


public class controller {

    private ObservableList<Expense> expenses = FXCollections.observableArrayList();
    private data data = new data("expenceTracker.txt");

    @FXML
    private Button add;

    @FXML
    private TextField amount;

    @FXML
    private TableColumn<Expense, Double> amountTable;

    @FXML
    private ComboBox<String> categories;

    @FXML
    private TableColumn<Expense, String> categoriesTable;

    @FXML
    private Button delete;

    @FXML
    private TextField description;

    @FXML
    private TableColumn<Expense, String> descriptionTable;

    @FXML
    private Button edit;

    @FXML
    private Label total;

    @FXML
    private Button view;

    @FXML
    private TableView<Expense> tableView;

    @FXML
    private void initialize() {
        categories.getItems().addAll("Meal", "Personal", "House", "Transportation", "Other");

        amountTable.setCellValueFactory(new PropertyValueFactory<>("amount"));
        descriptionTable.setCellValueFactory(new PropertyValueFactory<>("description"));
        categoriesTable.setCellValueFactory(new PropertyValueFactory<>("category")); 

        expenses.addAll(data.loadData());
        tableView.getItems().addAll(expenses);
        updateTotal();
    }

    @FXML
    private void handleAddButton() {
        String amountText = amount.getText();
        String descriptionText = description.getText();
        String category = categories.getValue();

        if (isValidInput(amountText, descriptionText, category)) {
            Expense newExpense = new Expense(Double.parseDouble(amountText), descriptionText, category);

            tableView.getItems().add(newExpense);
            data.saveData(tableView.getItems());
            updateTotal();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Input");
            alert.setHeaderText(null);
            alert.setContentText("Please enter valid input.");
            alert.showAndWait();
        }
    }

    private boolean isValidInput(String amount, String description, String category) {
        try {
            Double.parseDouble(amount);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @FXML
    void deleteButton(ActionEvent event) {
        Expense selectedExpense = tableView.getSelectionModel().getSelectedItem();
        if (selectedExpense != null) {
            Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
            confirmationAlert.setTitle("Confirm Deletion");
            confirmationAlert.setHeaderText(null);
            confirmationAlert.setContentText("Are you sure you want to delete this expense?");
            Optional<ButtonType> result = confirmationAlert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                tableView.getItems().remove(selectedExpense);
                data.saveData(tableView.getItems());
                updateTotal();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Expense Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select an expense to delete.");
            alert.showAndWait();
        }
    }

    @FXML
    void editButton(ActionEvent event) {

        Expense selectedExpense = tableView.getSelectionModel().getSelectedItem();
        if (selectedExpense != null) {
            TextInputDialog dialog = new TextInputDialog(selectedExpense.getAmount().toString());
            dialog.setTitle("Edit Expense");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter new amount:");

            Optional<String> result = dialog.showAndWait();
            result.ifPresent(amount -> {
                try {
                    double newAmount = Double.parseDouble(amount);
                    Expense updatedExpense = new Expense(newAmount, description.getText(), categories.getValue());
                    int selectedIndex = tableView.getSelectionModel().getSelectedIndex();
                    tableView.getItems().set(selectedIndex, updatedExpense);
                    data.saveData(tableView.getItems());
                    updateTotal();
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Invalid Input");
                    alert.setHeaderText(null);
                    alert.setContentText("Please enter a valid number.");
                    alert.showAndWait();
                }
            });
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Expense Selected");
                alert.setHeaderText(null);
                alert.setContentText("Please select an expense to edit.");
                alert.showAndWait();
    }
}

    @FXML
    void handleViewButton(ActionEvent event) {

    }


    public class Expense {
        private Double amount;
        private String description;
        private String category;

        public static void main(String[] args) {
            
        }
    
        public Expense(Double amount, String description, String category) {
            this.amount = amount;
            this.description = description;
            this.category = category;
        }
    
        public Double getAmount() {
            return amount;
        }
    
        public String getDescription() {
            return description;
        }
    
        public String getCategory() {
            return category;
        }
    }
    private void updateTotal() {
        double total2 = 0.0;
        for (Expense expense : tableView.getItems()) {
            total2 += expense.getAmount();
        }
        total.setText(String.format("%.2f", total2));
    }
}




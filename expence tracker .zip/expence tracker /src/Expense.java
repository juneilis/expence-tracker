

public class Expense {

    private Double amount;
        private String description;
        private String category;
        
        void main(){
            
        }
    
        public Expense(Double amount, String description, String category) {
            this.amount = amount;
            this.description = description;
            this.category = category;
        }
    
        public Double getAmount() {
            return amount;
        }
    
        public String getDescription() {
            return description;
        }
    
        public String getCategory() {
            return category;
        }
    }
    

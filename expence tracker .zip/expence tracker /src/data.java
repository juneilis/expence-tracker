import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class data {
    private final String filename;

    public data(String filename) {
        this.filename = filename;
    }

    public void saveData(List<controller.Expense> expenses) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (controller.Expense expense : expenses) {
                writer.println(expense.getAmount() + "," + expense.getDescription() + "," + expense.getCategory());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<controller.Expense> loadData() {
        List<controller.Expense> expenses = new ArrayList<>();
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filename))) {
            Object obj = inputStream.readObject();
            if (obj instanceof List) {
                List<?> list = (List<?>) obj;
                for (Object item : list) {
                    if (item instanceof controller.Expense) {
                        expenses.add((controller.Expense) item);
                    }
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return expenses;
    }
}
